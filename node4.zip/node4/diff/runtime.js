require('babel-core/register')({
  ignore: /\/lib\/|\/node_modules\//
});
