"use strict";
module.exports = require("@babel/core");
