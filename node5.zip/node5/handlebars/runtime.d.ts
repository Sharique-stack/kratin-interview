import Handlebars = require('handlebars')

declare module "handlebars/runtime" {
   
}