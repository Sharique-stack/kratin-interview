export { XmlEntities } from './xml-entities';
export { Html4Entities } from './html4-entities';
export { Html5Entities, Html5Entities as AllHtmlEntities } from './html5-entities';
