# @babel/plugin-external-helpers

> This plugin contains helper functions that’ll be placed at the top of the generated code

See our website [@babel/plugin-external-helpers](https://babeljs.io/docs/en/babel-plugin-external-helpers) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-external-helpers
```

or using yarn:

```sh
yarn add @babel/plugin-external-helpers --dev
```
