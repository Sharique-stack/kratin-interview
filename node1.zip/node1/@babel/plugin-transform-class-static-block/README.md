# @babel/plugin-transform-class-static-block

> Transform class static blocks

See our website [@babel/plugin-transform-class-static-block](https://babeljs.io/docs/en/babel-plugin-transform-class-static-block) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-class-static-block
```

or using yarn:

```sh
yarn add @babel/plugin-transform-class-static-block --dev
```
